package com.example.blackjack

data class Cartes(var valeur : Int, val couleur : String, val signe : String, val nom_carte : String) {

}